function [Gx, Gy, im_magnitude,im_direction] = compute_gradient(image)
fprintf('Not implemented\n')

end

